

<x-app-layout >
    @if (session('success'))
    <x-succes-notification>
        {{ session('success') }}
    </x-succes-notification>
    
    @endif
    <x-top-navbar-admin/>

    <div id="sidebar" class="lg:block z-20 hidden  bg-blue-800  w-64 h-screen fixed rounded-none border-none">
        <x-sidebar id="logo-sidebar" class="" />
    
    </div>
   
    <x-content-page-admin>
        @section('breadcrumbs')
            <x-breadcrumb :breadcrumbItems="$breadcrumbsItems" />
        @endsection
        <x-header>
            {{$pageTitle}}
        </x-header>
        <div class="md:p-6 p-2 mx-auto  mt-4 bg-white rounded-lg shadow-lg ">
           
            <div class="w-5/6 mx-auto">
                <h2 class="mb-4 text-lg font-bold text-gray-900 dark:text-white">Compléter les informations du mutualiste</h2>
                
                <form method="POST" action="{{ route('adherents.update', $adherent->id) }}" enctype="multipart/form-data">
                    @csrf
                    @method('PUT') 
                    
                    <dl class="grid gap-3 sm:grid-cols-2 grid-cols-1">

                        <!-- Nom -->
                        <div class="flex items-center space-x-2">
                            <dt class="text-sm font-medium text-gray-900 dark:text-white">Nom :</dt>
                            <dd class="text-sm font-semibold text-gray-700 dark:text-gray-300">
                                {{ old('nom', $adherent->nom) }}
                            </dd>
                        </div>

                        

                        <!-- Téléphone -->
                        <div class="flex items-center space-x-2">
                            <dt class="text-sm font-medium text-gray-900 dark:text-white">Téléphone :</dt>
                            <dd class="text-sm font-semibold text-gray-700 dark:text-gray-300">
                                {{ old('telephone', $adherent->telephone) }}
                            </dd>
                        </div>
                        <!-- Prénom(s) -->
                        <div class="flex items-center space-x-2">
                            <dt class="text-sm font-medium text-gray-900 dark:text-white">Prénom(s) :</dt>
                            <dd class="text-sm font-semibold text-gray-700 dark:text-gray-300">
                                {{ old('prenom', $adherent->prenom) }}
                            </dd>
                        </div>

                        

                        <!-- Email -->
                        <div class="flex items-center space-x-2">
                            <dt class="text-sm font-medium text-gray-900 dark:text-white">Email :</dt>
                            <dd class="text-sm font-semibold text-gray-700 dark:text-gray-300">
                                {{ old('email', $adherent->email) }}
                            </dd>
                        </div>
                        <!-- Matricule -->
                        <div class="flex items-center space-x-2">
                            <dt class="text-sm font-medium text-gray-900 dark:text-white">Matricule :</dt>
                            <dd class="text-sm font-semibold text-gray-700 dark:text-gray-300">
                                {{ old('matricule', $adherent->matricule) }}
                            </dd>
                        </div>
                                            
                    </dl>
                    
                    <h6 class="my-3 underline text-blue-900 font-semibold">
                        <i class="fa fa-pencil-square-o"></i>
                        Informations à compléter
                    </h6>
                    <div>
                        <fieldset class=" border-2 border-slate-300 shadow-sm p-2 mt-1 mb-3 rounded-md bg-slate-200">
                            <legend class="block text-gray-700 text-sm font-bold mb-2">Divisions administratives</legend>
                            
                            <div class="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 grid-cols-1 sm:gap-6">
        
                
                                <!-- Région -->
                                <div class="w-full">
                                    <label for="region" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Région</label>
                                    <select name="region" id="region" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500" required>
                                        <option value="" disabled selected>Sélectionnez une région</option>
                                    </select>
                                    @error('region')
                                        <p class="text-sm text-red-600">{{ $message }}</p>
                                    @enderror
                                </div>
                
                                <!-- Province -->
                                <div class="w-full">
                                    <label for="province" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Province</label>
                                    <select name="province" id="province" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500" required>
                                        <option value="" disabled selected>Choisissez d&apos;abord votre région</option>
                                    </select>
                                    @error('province')
                                        <p class="text-sm text-red-600">{{ $message }}</p>
                                    @enderror
                                </div>
                                <!-- Localité -->
                                <div class="w-full">
                                    <label for="localite" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Localité</label>
                                    <input type="text" name="localite" id="localite" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500" required>
                                    @error('localite')
                                        <p class="text-sm text-red-600">{{ $message }}</p>
                                    @enderror
                                </div>
                            </div>
                        </fieldset>
                        <fieldset class=" border-2 border-gray-300 shadow-sm p-2 mt-1 mb-3 rounded-md bg-gray-100">
                            <legend class="block text-gray-700 text-sm font-bold mb-2">1. Références</legend>
                            <div class="grid gap-3 sm:grid-cols-2 grid-cols-1 sm:gap-6">
                                <!-- NIP -->
                                <div class="w-full">
                                    <label for="nip" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">NIP</label>
                                    <input type="text" name="nip" id="nip" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500" value="{{ old('nip', $adherent->nip) }}" required>
                                    @error('nip')
                                        <p class="text-sm text-red-600">{{ $message }}</p>
                                    @enderror
                                </div>
        
                                <!-- CNIB -->
                                <div class="w-full">
                                    <label for="cnib" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">CNIB</label>
                                    <input type="text" name="cnib" id="cnib" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500" value="{{ old('cnib', $adherent->cnib) }}" required>
                                    @error('cnib')
                                        <p class="text-sm text-red-600">{{ $message }}</p>
                                    @enderror
                                </div>
        
                                <!-- Délivrée -->
                                <div class="w-full">
                                    <label for="delivree" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Délivrée le</label>
                                    <input type="date" name="delivree" id="delivree" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500" value="{{ old('delivree', $adherent->delivree) }}" required>
                                    @error('delivree')
                                        <p class="text-sm text-red-600">{{ $message }}</p>
                                    @enderror
                                </div>
        
                                <!-- Expire -->
                                <div class="w-full">
                                    <label for="expire" class="block mb-2 text-sm bg-gray-50 font-medium text-gray-900 dark:text-white">Expire le</label>
                                    <input type="date" name="expire" id="expire" readonly class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500" value="{{ old('expire', $adherent->expire) }}" required>
                                    @error('expire')
                                        <p class="text-sm text-red-600">{{ $message }}</p>
                                    @enderror
                                </div>

                                <script>
                                    document.addEventListener("DOMContentLoaded", function () {
                                        const delivreeInput = document.getElementById('delivree');
                                        const expireInput = document.getElementById('expire');
                                
                                        // Fonction pour ajouter 10 ans à la date de délivrance
                                        function updateExpireDate() {
                                            const delivreeDate = new Date(delivreeInput.value);
                                            if (delivreeDate.getFullYear() !== 1970) { // Assure que la date est valide
                                                delivreeDate.setFullYear(delivreeDate.getFullYear() + 10); // Ajouter 10 ans
                                                delivreeDate.setDate(delivreeDate.getDate() - 1); // Soustraire 1 jour

                                                // Formater la nouvelle date au format YYYY-MM-DD
                                                const expireDate = delivreeDate.toISOString().split('T')[0];
                                                expireInput.value = expireDate;
                                            }
                                        }
                                
                                        // Ajouter un événement pour mettre à jour la date d'expiration lorsqu'une date est sélectionnée
                                        delivreeInput.addEventListener('change', updateExpireDate);
                                
                                        // Initialiser la date d'expiration au chargement de la page si une date de délivrance est déjà sélectionnée
                                        if (delivreeInput.value) {
                                            updateExpireDate();
                                        }
                                    });
                                </script>
                                <!-- Adresse -->
    
                                <div class="w-full ">
                                    <label for="adresse" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Adresse</label>
                                    <input type="text"  name="adresse" id="adresse" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500" placeholder="Adresse" value="{{ old('adresse', $adherent->adresse) }}" required>
                                    @error('adresse')
                                        <p class="text-sm text-red-600">{{ $message }}</p>
                                    @enderror
                                </div>
                            </div>
                        </fieldset>
                        <fieldset class=" border-2 border-gray-300 shadow-sm p-2 mt-1 mb-3 rounded-md bg-gray-100">
                            <legend class="block text-gray-700 text-sm font-bold mb-2">2. Etat civil</legend>
                            <div class="grid gap-3 sm:grid-cols-2 grid-cols-1 sm:gap-6">
                                <!-- Genre -->
                                <div class="w-full">
                                    <label class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Genre</label>
                                    <div class="flex items-center space-x-4">
                                        <div>
                                            <input type="radio" id="genre_masculin" name="genre" value="M" {{ old('genre', $adherent->genre) == 'Masculin' ? 'checked' : '' }} required>
                                            <label for="genre_masculin" class="text-sm text-gray-900 dark:text-white">Masculin</label>
                                        </div>
                                        <div>
                                            <input type="radio" id="genre_feminin" name="genre" value="F" {{ old('genre', $adherent->genre) == 'Féminin' ? 'checked' : '' }} required>
                                            <label for="genre_feminin" class="text-sm text-gray-900 dark:text-white">Féminin</label>
                                        </div>
                                    </div>
                                    @error('genre')
                                        <p class="text-sm text-red-600">{{ $message }}</p>
                                    @enderror
                                </div> 
                                <div class="w-full col-span-2" >
                                    <fieldset class=" border-2 border-slate-300 shadow-sm p-2 mt-1 mb-3 rounded-md bg-slate-200">
                                        <legend class="block text-gray-700 text-sm font-bold mb-2">Lieu de naissance</legend>
                                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                                            <!-- Département -->
                                            <div class="w-full">
                                                <label for="departement" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Département</label>
                                                <input type="text" name="departement" id="departement" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500" value="{{ old('departement', $adherent->departement) }}" required>
                                                @error('departement')
                                                    <p class="text-sm text-red-600">{{ $message }}</p>
                                                @enderror
                                            </div>
                    
                                            <!-- Ville -->
                                            <div class="w-full">
                                                <label for="ville" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Ville</label>
                                                <input type="text" name="ville" id="ville" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500" value="{{ old('ville', $adherent->ville) }}" required>
                                                @error('ville')
                                                    <p class="text-sm text-red-600">{{ $message }}</p>
                                                @enderror
                                            </div>
                    
                                            <!-- Pays -->
                                            <div class="w-full">
                                                <label for="pays" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Pays</label>
                                                <input type="text" name="pays" id="pays" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500" value="{{ old('pays', $adherent->pays) }}" required>
                                                @error('pays')
                                                    <p class="text-sm text-red-600">{{ $message }}</p>
                                                @enderror
                                            </div>
                                        </div>
                                    </fieldset>
                                </div> 

                                <!-- Nom du père -->
                                <div class="w-full">
                                    <label for="nom_pere" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Nom et prénom du père</label>
                                    <input type="text" name="nom_pere" id="nom_pere" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500" value="{{ old('nom_pere', $adherent->nom_pere) }}" required>
                                    @error('nom_pere')
                                        <p class="text-sm text-red-600">{{ $message }}</p>
                                    @enderror
                                </div>
        
                                <!-- Nom de la mère -->
                                <div class="w-full">
                                    <label for="nom_mere" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Nom et prénom de la mère</label>
                                    <input type="text" name="nom_mere" id="nom_mere" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500" value="{{ old('nom_mere', $adherent->nom_mere) }}" required>
                                    @error('nom_mere')
                                        <p class="text-sm text-red-600">{{ $message }}</p>
                                    @enderror
                                </div>
        
                                </div>
                            </div>
                        </fieldset>
                        <fieldset class="border-2 border-gray-300 shadow-sm p-2 mt-1 mb-3 rounded-md bg-gray-100">
                            <legend class="block text-gray-700 text-sm font-bold mb-2">3. Informations personnelles</legend>
                            <div class="grid gap-3 sm:grid-cols-2 grid-cols-1 sm:gap-6">
                                <!-- Situation matrimoniale -->
                                <div class="w-full">
                                    <label for="situation_matrimoniale" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Situation matrimoniale</label>
                                    <select name="situation_matrimoniale" id="situation_matrimoniale" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500" required>
                                        <option value="Célibataire" {{ old('situation_matrimoniale', $adherent->situation_matrimoniale) == 'Célibataire' ? 'selected' : '' }}>Célibataire</option>
                                        <option value="Marié(e)" {{ old('situation_matrimoniale', $adherent->situation_matrimoniale) == 'Marié' ? 'selected' : '' }}>Marié(e)</option>
                                        <option value="Divorcé(e)" {{ old('situation_matrimoniale', $adherent->situation_matrimoniale) == 'Divorcé' ? 'selected' : '' }}>Divorcé(e)</option>
                                    
                                        <option value="Veuf(ve)" {{ old('situation_matrimoniale', $adherent->situation_matrimoniale) == 'Divorcé' ? 'selected' : '' }}>Veuf(ve)</option>
                                    </select>
                                    @error('situation_matrimoniale')
                                        <p class="text-sm text-red-600">{{ $message }}</p>
                                    @enderror
                                </div>
        
                                <!-- Nombre ayants droits -->
                                <div class="w-full">
                                    <label for="nombreAyantsDroits" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Nombre d’ayants droits</label>
                                    <select name="nombreAyantsDroits" id="nombreAyantsDroits" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500" required>
                                        @for ($i = 0; $i <= 6; $i++)
                                            <option value="{{ $i }}" {{ old('nombreAyantsDroits', $adherent->nombreAyantsDroits) == $i ? 'selected' : '' }}>{{ $i }}</option>
                                        @endfor
                                    </select>
                                    @error('nombreAyantsDroits')
                                        <p class="text-sm text-red-600">{{ $message }}</p>
                                    @enderror
                                </div>
                                <fieldset class="col-span-2 border-2 border-slate-300 shadow-sm p-2 mt-1 mb-3 rounded-md bg-slate-200">
                                    <legend class="block text-gray-700 text-sm font-bold mb-2">Personne à prévenir</legend>
                                    <div class="grid gap-3 sm:grid-cols-2 grid-cols-1 sm:gap-6">
                                        <!-- Nom et prénom de la personne à prévenir -->
                                        <div class="w-full col-span-2">
                                            <label for="nom_prenom_personne_besoin" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Nom et prénom de la personne à prévenir</label>
                                            <input type="text" name="nom_prenom_personne_besoin" id="nom_prenom_personne_besoin" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500" value="{{ old('nom_prenom_personne_besoin', $adherent->nom_prenom_personne_besoin) }}" required>
                                            @error('nom_prenom_personne_besoin')
                                                <p class="text-sm text-red-600">{{ $message }}</p>
                                            @enderror
                                        </div>
                
                                        <!-- Lieu de résidence -->
                                        <div class="w-full">
                                            <label for="lieu_residence" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Lieu de résidence</label>
                                            <input type="text" name="lieu_residence" id="lieu_residence" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500" value="{{ old('lieu_residence', $adherent->lieu_residence) }}" required>
                                            @error('lieu_residence')
                                                <p class="text-sm text-red-600">{{ $message }}</p>
                                            @enderror
                                        </div>
                
                                        <!-- Téléphone personne à prévenir -->
                                        <div class="w-full">
                                            <label for="telephone_personne_prevenir" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Téléphone de la personne à prévenir</label>
                                            <input type="number" name="telephone_personne_prevenir" id="telephone_personne_prevenir" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500" value="{{ old('telephone_personne_prevenir', $adherent->telephone_personne_prevenir) }}" required>
                                            @error('telephone_personne_prevenir')
                                                <p class="text-sm text-red-600">{{ $message }}</p>
                                            @enderror
                                        </div>
                                    </div>

                                </fieldset>
 

                                <!-- Tableau pour les ayants droits -->
                                
                                <div class="w-full col-span-2 mt-1"  id="ayantsDroitsTableContainer" style="display: none; width:100%">
                                    <label for="ayant droits" class="block  text-sm font-medium text-gray-900 dark:text-white">Liste Ayants droit</label>
                                    <table class="w-full table-auto min-w-full border bg-white border-gray-300 overflow-x-auto text-sm">
                                        <thead class="bg-gray-100 dark:bg-gray-700">
                                            <tr>
                                                <th class="border px-1 py-1 text-left text-sm">N°</th>
                                                <th class="border px-1 py-1 text-left text-sm">Nom</th>
                                                <th class="border px-1 py-1 text-left text-sm">Prénom</th>
                                                <th class="border px-1 py-1 text-left text-sm">Sexe</th>
                                                <th class="border px-1 py-1 text-left text-sm">Date de naissance</th>
                                                <th class="border px-1 py-1 text-left text-sm">Relation</th>
                                            </tr>
                                        </thead>
                                        <tbody id="ayantsDroitsTableBody" class="!text-xs"></tbody>
                                    </table>
                                </div>
                                
                                <script>
                                    document.addEventListener("DOMContentLoaded", function () {
                                        const nombreAyantsDroitsSelect = document.getElementById("nombreAyantsDroits");
                                        const tableContainer = document.getElementById("ayantsDroitsTableContainer");
                                        const tableBody = document.getElementById("ayantsDroitsTableBody");
                                
                                        nombreAyantsDroitsSelect.addEventListener("change", function () {
                                            const nombre = parseInt(this.value);
                                            tableBody.innerHTML = ""; // Clear previous rows
                                
                                            if (nombre > 0) {
                                                tableContainer.style.display = "block";
                                                tableContainer.style.width = "100%";

                                                for (let i = 0; i < nombre; i++) {
                                                    const row = document.createElement("tr");
                                
                                                    row.innerHTML = `
                                                        <td class="border px-1 py-1 ">
                                                            <input type="text" readonly value="${i+1}" name="ayantsDroits[${i}][position]" class="w-8 border rounded-md text-xs" required>
                                                        </td>
                                                        <td class="border px-1 py-1 ">
                                                            <input type="text" name="ayantsDroits[${i}][nom]" class="w-full p-2 border rounded-md text-xs" required>
                                                        </td>
                                                        <td class="border px-1 py-1">
                                                            <input type="text" name="ayantsDroits[${i}][prenom]" class="w-full p-2 border rounded-md text-xs" required>
                                                        </td>
                                                        <td class="border px-1 py-1">
                                                            <select name="ayantsDroits[${i}][sexe]" class="w-full p-2 border rounded-md text-xs" required>
                                                                <option value="" disabled selected>-- Sexe --</option>
                                                                <option value="M">M</option>
                                                                <option value="F">F</option>
                                                            </select>
                                                        </td>
                                                        <td class="border px-1 py-1">
                                                            <input type="date" name="ayantsDroits[${i}][date_naissance]" class="w-full p-2 border rounded-md text-xs" required>
                                                        </td>
                                                        <td class="border px-2 py-1">
                                                            <select name="ayantsDroits[${i}][relation]" class="w-full p-2 border rounded-md text-xs" required>
                                                                <option value="" disabled selected>-- Relation --</option>
                                                                <option value="Enfant">Enfant</option>
                                                                <option value="Conjoint(e)">Conjoint(e)</option>
                                                            </select>
                                                        </td>
                                                    `;
                                
                                                    tableBody.appendChild(row);
                                                }
                                            } else {
                                                tableContainer.style.display = "none";
                                            }
                                        });
                                
                                        // Trigger change event on page load to populate existing data
                                        nombreAyantsDroitsSelect.dispatchEvent(new Event("change"));
                                    });
                                </script>
                                

                                
                            </div>


                        </fieldset>
                        <fieldset class="border-2 border-gray-300 shadow-sm p-2 mt-1 mb-3 rounded-md bg-gray-100">
                            <legend class="block text-gray-700 text-sm font-bold mb-2">4. Informations professionnelles</legend>
                            
                            <!-- Statut -->
                            <div class="w-full">
                                <label class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Statut</label>
                                <div class="flex items-center space-x-4">
                                    <div>
                                        <input type="radio" id="personnel_retraite" name="statut" value="personnel_retraite" required onclick="handleStatutChange('retraite')">
                                        <label for="personnel_retraite" class="text-sm text-gray-900 dark:text-white">Retraité</label>
                                    </div>
                                    <div>
                                        <input type="radio" id="personnel_active" name="statut" value="personnel_active" required onclick="handleStatutChange('actif')">
                                        <label for="personnel_active" class="text-sm text-gray-900 dark:text-white">En activité</label>
                                    </div>
                                </div>
                                @error('statut')
                                    <p class="text-sm text-red-600">{{ $message }}</p>
                                @enderror
                            </div>
                            <div class="grid gap-3 sm:grid-cols-2 grid-cols-1 sm:gap-6">
                                <!-- Champs pour retraité -->
                                <div id="retraiteFields" class="hidden ">
                                    <div class="w-full">
                                        <label for="numeroCARFO" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Numéro CARFO</label>
                                        <input type="text" name="numeroCARFO" id="numeroCARFO" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white">
                                    </div>
                                   
                                </div>
                            
                                <!-- Champs pour actif -->
                                <div id="actifFields" class="hidden ">
                                    <div class="w-full">
                                        <label for="dateIntegration" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Date d&apos;intégration</label>
                                        <input type="date" name="dateIntegration" id="dateIntegration" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white">
                                    </div>
                                </div>
    
                                <!-- dateDepartARetraite-->
                                <div class="w-full">
                                    <label for="dateDepartARetraite" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Date de départ retraite</label>
                                    <input type="date" name="dateDepartARetraite" id="dateDepartARetraite" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500" required>
                                    @error('dateDepartARetraite')
                                        <p class="text-sm text-red-600">{{ $message }}</p>
                                    @enderror
                                </div>
                            </div>

                            <div class="grid gap-3 sm:grid-cols-2 md:grid-cols-3 grid-cols-1 sm:gap-6">

                                <!-- Grade -->
                                <div class="w-full">
                                    <label for="grade" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Grade</label>
                                    <select name="grade" id="grade" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500" required>
                                        <option value="" disabled selected>-- Sélectionnez un grade --</option>
                                    </select>
                                    @error('grade')
                                        <p class="text-sm text-red-600">{{ $message }}</p>
                                    @enderror
                                </div>
    
                                <script>
                            
                            
                                    document.addEventListener("DOMContentLoaded", function() {
                                        const regionSelect = document.getElementById("region");
                                        const provinceSelect = document.getElementById("province");
                                        const gradeSelect = document.getElementById("grade");
    
                                        for (const region in regions) {
                                            const option = document.createElement("option");
                                            option.value = region;
                                            option.textContent = region;
                                            regionSelect.appendChild(option);
                                        }
                                        grades.forEach(grade => {
                                            const option = document.createElement("option");
                                            option.value = grade;
                                            option.textContent = grade;
                                            gradeSelect.appendChild(option);
                                        });
                                        
                                    
                                        regionSelect.addEventListener("change", function() {
                                            const selectedRegion = regionSelect.value;
                                    
                                            provinceSelect.innerHTML = "";
                                            provinceSelect.disabled = false;
                                    
                                            const defaultOption = document.createElement("option");
                                            defaultOption.value = "";
                                            defaultOption.disabled = true;
                                            defaultOption.selected = true;
                                            defaultOption.textContent = "Choisissez votre province";
                                            provinceSelect.appendChild(defaultOption);
                                    
                                            regions[selectedRegion].provinces.forEach(province => {
                                                const option = document.createElement("option");
                                                option.value = province;
                                                option.textContent = province;
                                                provinceSelect.appendChild(option);
                                            });
                                        });
                                    });
                                    
                                </script>
                                <!-- Service-->
                                <div class="w-full">
                                    <label for="service" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Service</label>
                                    <input type="text" name="service" id="service" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500" required>
                                    @error('service')
                                        <p class="text-sm text-red-600">{{ $message }}</p>
                                    @enderror
                                </div>
                                <!-- Direction-->
                                <div class="w-full">
                                    <label for="direction" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Direction</label>
                                    <input type="text" name="direction" id="direction" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500" required>
                                    @error('direction')
                                        <p class="text-sm text-red-600">{{ $message }}</p>
                                    @enderror
                                </div>
                            </div>

                        </fieldset>
                        
                        <script>
                            // Fonction pour afficher/masquer les champs selon le statut
                            function handleStatutChange(statut) {
                                const retraiteFields = document.getElementById('retraiteFields');
                                const actifFields = document.getElementById('actifFields');
                        
                                if (statut === 'retraite') {
                                    retraiteFields.classList.remove('hidden');
                                    actifFields.classList.add('hidden');
                                } else if (statut === 'actif') {
                                    actifFields.classList.remove('hidden');
                                    retraiteFields.classList.add('hidden');
                                }
                            }
                        </script>
                        

                        <div class="grid gap-3 sm:grid-cols-2 grid-cols-1 sm:gap-6">
    
    
                            <!-- Date enregistrement -->
                            <div class="w-full">
                                <label for="date_enregistrement" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Date d&apos;adhésion</label>
                                <input type="date" name="date_enregistrement" id="date_enregistrement" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500" value="{{ old('date_enregistrement', $adherent->date_enregistrement) }}" required>
                                @error('date_enregistrement')
                                    <p class="text-sm text-red-600">{{ $message }}</p>
                                @enderror
                            </div>
                            
            
                            
                        </div>
                    </div>
                   
                    <div class="flex justify-end">
                        <x-primary-button type="submit" class="mt-5 ">
                            Créer le compte
                        </x-primary-button>
            
                    </div>
                </form>
            </div>
            
        </div>
    </x-content-page-admin>
    
</x-app-layout>

