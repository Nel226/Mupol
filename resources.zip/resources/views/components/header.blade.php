<div class="flex items-center  px-4 py-2 mb-4 text-gray-500 bg-[#fffe4a70] rounded-t-lg shadow-lg">
    <h1 class="flex-1 text-sm sm:text-lg tracking-tight font-bold">
        {{ $slot }}
    </h1>
</div>