<footer>
    <div class="px-6 border-t border-gray-300 py-3 flex justify-center items-center">
       <p class="m-0 leading-6">
        © Copyright {{ date('Y') }} | Tous droits réservés par <a href="/" target="_blank">MU-POL</a>

       </p>
       
    </div>
 </footer>
 