<!-- start navbar -->
<div class="header">
   <!-- navbar -->
   <nav class="bg-white px-6 py-[10px] flex items-center justify-between shadow-sm">
     
    <div>
        <div class="flex items-center space-x-1">

            <button id="nav-toggle" class="text-gray-800 focus:outline-none lg:hidden">
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                 <path stroke-linecap="round" stroke-linejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
              </svg>
            </button>
            <img class="h-12 lg:hidden" src="{{ asset('images/logofinal.png') }}" alt="Logo">
            <h5 class="lg:hidden text-primary1 font-bold">{{ config('app.name') }}</h5>
        </div>
        <!-- Dropdown menu (masqué par défaut) -->
        
        <!-- navbar nav -->
        <div id="dropdown-menu" class="hidden bg-white shadow-md z-50">
          
          @if (Auth::guard('adherent')->check())
            <ul class="flex-col ml-auto items-center">
                <!-- Liens du menu -->
                <li class="dropdown stopevent mr-2">
                    <a href="{{ route('adherents.dashboard') }}" 
                    class="@if(Request::is('adherents/dashboard')) active @endif block text-gray-800 hover:bg-gray-200 rounded-md px-2 py-1">Mon Profil
                    </a>
                </li>
                <li class="dropdown stopevent mr-2">
                <a href="{{ route('adherents.prestations') }}" class="@if(Request::is('adherents/prestations*')) active @endif block text-gray-800 hover:bg-gray-200 rounded-md px-2 py-1">Demande de remboursement</a>
                </li>
                <li class="dropdown stopevent mr-2">
                <a href="{{ route('adherents.ayantsdroits') }}" class="@if(Request::is('adherents/ayantsdroits') || Request::is('adherents/ayantsdroits/*')) active @endif block text-gray-800 hover:bg-gray-200 rounded-md px-2 py-1">Mes ayants droits</a>
                </li>
                
            </ul>
          @endif
          @if (Auth::guard('partenaire')->check())
            <ul class="flex-col ml-auto items-center">
                <!-- Liens du menu -->
                <li class="dropdown stopevent mr-2">
                    <a href="{{ route('partenaires.dashboard') }}" 
                    class="@if(Request::is('partenaires/dashboard')) active @endif block text-gray-800 hover:bg-gray-200 rounded-md px-2 py-1">Profil
                    </a>
                </li>
                <li class="dropdown stopevent mr-2">
                <a href="{{ route('partenaires.nouvelle-prestation') }}" class="@if(Request::is('partenaire/prestations*') || Request::is('partenaire/rechercher-adherent')) active @endif block text-gray-800 hover:bg-gray-200 rounded-md px-2 py-1">Recherche</a>
                </li>
                <li class="dropdown stopevent mr-2">
                <a href="{{ route('partenaire.restrictions') }}" class="@if(Request::is('partenaires/restrictions')) active @endif block text-gray-800 hover:bg-gray-200 rounded-md px-2 py-1">Restrictions</a>
                </li>
                
            </ul>
          @endif

        </div>
        <script>
          document.addEventListener("DOMContentLoaded", () => {
              const navToggle = document.getElementById("nav-toggle");
              const dropdownMenu = document.getElementById("dropdown-menu");
           
              navToggle.addEventListener("click", () => {
                 if (dropdownMenu.classList.contains("hidden")) {
                    dropdownMenu.classList.remove("hidden");
                    dropdownMenu.classList.add("block");
                 } else {
                    dropdownMenu.classList.remove("block");
                    dropdownMenu.classList.add("hidden");
                 }
              });
           });
           
        </script>

    </div>
      <ul class="flex ml-auto items-center">
        <li class="dropdown stopevent mr-2">
            @if (Auth::guard('adherent')->check())
                <form method="POST" action="{{ route('adherent.logout') }}" class="text-gray-600">
                    @csrf
                    <button type="submit" class="text-gray-600" id="dropdownNotification" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fa  fa-sign-out-alt w-6 h-6"></i> 
                    </button>
                </form>
                
            @elseif (Auth::guard('partenaire')->check())
                <form method="POST" action="{{ route('partenaire.logout') }}" class="">
                    @csrf
                    <button type="submit" class="text-gray-600" id="dropdownNotification" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fa  fa-sign-out-alt w-6 h-6"></i> 
                    </button>
                </form>
               
            @else
                <a class="text-gray-600" href="#" role="button" id="dropdownNotification" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class=" fa fa-sign-out-alt w-6 h-6"></i>
                </a>
            @endif
           {{-- <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
              <path
                 stroke-linecap="round"
                 stroke-linejoin="round"
                 d="M14.857 17.082a23.848 23.848 0 005.454-1.31A8.967 8.967 0 0118 9.75v-.7V9A6 6 0 006 9v.75a8.967 8.967 0 01-2.312 6.022c1.733.64 3.56 1.085 5.455 1.31m5.714 0a24.255 24.255 0 01-5.714 0m5.714 0a3 3 0 11-5.714 0M3.124 7.5A8.969 8.969 0 015.292 3m13.416 0a8.969 8.969 0 012.168 4.5" />
           </svg> --}}
           <div class="dropdown-menu dropdown-menu-lg lg:left-auto lg:right-0" aria-labelledby="dropdownNotification">
              <div>
                 <div class="border-b px-3 pt-2 pb-3 flex justify-between items-center">
                    <span class="text-lg text-gray-800 font-semibold">Notifications</span>
                    <a href="#">
                       <span>
                          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4">
                             <path
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                d="M9.594 3.94c.09-.542.56-.94 1.11-.94h2.593c.55 0 1.02.398 1.11.94l.213 1.281c.063.374.313.686.645.87.074.04.147.083.22.127.324.196.72.257 1.075.124l1.217-.456a1.125 1.125 0 011.37.49l1.296 2.247a1.125 1.125 0 01-.26 1.431l-1.003.827c-.293.24-.438.613-.431.992a6.759 6.759 0 010 .255c-.007.378.138.75.43.99l1.005.828c.424.35.534.954.26 1.43l-1.298 2.247a1.125 1.125 0 01-1.369.491l-1.217-.456c-.355-.133-.75-.072-1.076.124a6.57 6.57 0 01-.22.128c-.331.183-.581.495-.644.869l-.213 1.28c-.09.543-.56.941-1.11.941h-2.594c-.55 0-1.02-.398-1.11-.94l-.213-1.281c-.062-.374-.312-.686-.644-.87a6.52 6.52 0 01-.22-.127c-.325-.196-.72-.257-1.076-.124l-1.217.456a1.125 1.125 0 01-1.369-.49l-1.297-2.247a1.125 1.125 0 01.26-1.431l1.004-.827c.292-.24.437-.613.43-.992a6.932 6.932 0 010-.255c.007-.378-.138-.75-.43-.99l-1.004-.828a1.125 1.125 0 01-.26-1.43l1.297-2.247a1.125 1.125 0 011.37-.491l1.216.456c.356.133.751.072 1.076-.124.072-.044.146-.087.22-.128.332-.183.582-.495.644-.869l.214-1.281z" />
                             <path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                          </svg>
                       </span>
                    </a>
                 </div>
                 <!-- list group -->
                 <ul class="h-56" data-simplebar="">
                    <!-- list group item -->
                    <li class="bg-gray-100 px-3 py-2 border-b">
                       <a href="#">
                          <h5 class="mb-1">Rishi Chopra</h5>
                          <p class="mb-0">Mauris blandit erat id nunc blandit, ac eleifend dolor pretium.</p>
                       </a>
                    </li>
                    <!-- list group item -->
                    <li class="px-3 py-2 border-b">
                       <a href="#">
                          <h5 class="mb-1">Neha Kannned</h5>
                          <p class="mb-0">Proin at elit vel est condimentum elementum id in ante. Maecenas et sapien metus.</p>
                       </a>
                    </li>
                    <!-- list group item -->
                    <li class="px-3 py-2 border-b">
                       <a href="#">
                          <h5 class="mb-1">Nirmala Chauhan</h5>
                          <p class="mb-0">Morbi maximus urna lobortis elit sollicitudin sollicitudieget elit vel pretium.</p>
                       </a>
                    </li>
                    <!-- list group item -->
                    <li class="px-3 py-2 border-b">
                       <a href="#">
                          <h5 class="mb-1">Sina Ray</h5>
                          <p class="mb-0">Sed aliquam augue sit amet mauris volutpat hendrerit sed nunc eu diam.</p>
                       </a>
                    </li>
                 </ul>
                 <div class="border-top px-3 py-2 text-center">
                    <a href="#" class="text-gray-800 font-semibold">View all Notifications</a>
                 </div>
              </div>
           </div>
        </li>
        <!-- list -->
        <li class="dropdown ml-2">
           <a class="rounded-full" href="#" role="button" id="dropdownUser" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <div class="w-10 h-10 relative">
                @if (Auth::guard('adherent')->check())
                    <img alt="avatar" src="{{  asset('storage/' . $adherent->photo)}}" class="rounded-full" />
                @elseif (Auth::guard('partenaire')->check())
                    <img alt="avatar" src="{{ asset('storage/' . Auth::guard('partenaire')->user()->photo) }}" class="rounded-full" />
                @else
                    <img src="{{ asset('images/user-90.png') }}" alt="Default Profile" class="h-10 w-10 rounded-full mr-3">
                @endif
                 
              </div>
           </a>
          
        </li>
     </ul>
   </nav>
</div>
<!-- end of navbar -->
