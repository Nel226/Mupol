<section class="bg-white rounded-md dark:bg-gray-900 px-4 py-4 mx-auto lg:py-8">
    {{ $slot }}
</section>