<div class=" max-w-5xl mx-auto my-5">
    <!-- Contenu du slot -->
    {{ $slot }}
</div>