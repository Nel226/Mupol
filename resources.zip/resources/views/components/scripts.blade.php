<!-- Libs JS -->
<script src="@@webRoot/node_modules/feather-icons/dist/feather.min.js"></script>
<script src="@@webRoot/node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<script src="@@webRoot/node_modules/simplebar/dist/simplebar.min.js"></script>

<!-- Theme JS -->
<!-- build:js @@webRoot/assets/js/theme.min.js -->
<script src="@@webRoot/assets/js/theme.js"></script>
<!-- endbuild -->
